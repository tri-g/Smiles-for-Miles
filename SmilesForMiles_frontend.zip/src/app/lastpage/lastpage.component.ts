import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lastpage',
  templateUrl: './lastpage.component.html',
  styleUrls: ['./lastpage.component.css']
})
export class LastpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
