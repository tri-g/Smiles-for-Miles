export class ProductInformation {
 product_id: string;
	 category_type: number;  
 create_time: string; 
	 product_description: string; 
	 product_icon: string;  
	 product_name: string;  
	 product_price:string; 
	product_status: number;  
	product_stock: number; 
	update_time: string;

	


}
