export class Users {
	 id: number;
	active: boolean;
  address: string;
	 email:string;
	 name:string;
	 password:string;
	 phone:string;
	role:string;
}
